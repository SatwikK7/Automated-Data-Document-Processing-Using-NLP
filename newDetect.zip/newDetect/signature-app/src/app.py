from flask import Flask, request, render_template, send_from_directory
import os
from pdf_to_images import crop_and_save_signatures_from_pdf

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['SIGNATURE_FOLDER'] = 'static/signatures'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'pdf' not in request.files:
        return "No file part 1", 400
    file = request.files['pdf']
    if file.filename == '':
        return "No selected file", 400
    if file and file.filename.endswith('.pdf'):
        pdf_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(pdf_path)

        # Process the PDF to extract signatures
        model_path = "best.pt"  # Path to your YOLOv8 model
        output_folder = app.config['SIGNATURE_FOLDER']
        confidence_threshold = 0.25
        dpi = 300

        crop_and_save_signatures_from_pdf(model_path, pdf_path, output_folder, confidence_threshold, dpi)

        return "File processed successfully", 200
    else:
        return "Invalid file type. Please upload a PDF.", 400

@app.route('/signatures/<path:filename>')
def get_signature(filename):
    return send_from_directory(app.config['SIGNATURE_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True)