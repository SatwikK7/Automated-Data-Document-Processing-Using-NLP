# Signature Detection App

This project is a web application designed to detect and extract signatures from PDF documents using a YOLOv8 model. It allows users to upload PDF files, processes them to find signatures, and saves the extracted signatures for further comparison or analysis.

## Project Structure

```
signature-app
├── src
│   ├── pdf_to_images.py  # Contains functions for PDF to image conversion and signature detection
│   └── app.py            # Backend application handling HTTP requests and file uploads
├── static
│   └── signatures         # Directory for storing cropped signature images
├── templates
│   └── index.html        # Frontend UI for file uploads
├── requirements.txt       # Lists project dependencies
└── README.md              # Project documentation
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd signature-app
   ```

2. Create a virtual environment (optional but recommended):
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage

1. Start the application:
   ```
   python src/app.py
   ```

2. Open your web browser and navigate to `http://localhost:5000` (or the specified port).

3. Use the provided form to upload a PDF file containing signatures.

4. The application will process the PDF, extract signatures, and save them in the `static/signatures` directory.

5. Results will be displayed on the frontend, showing the extracted signatures.

## Dependencies

- Flask
- OpenCV
- PyMuPDF
- YOLOv8
- NumPy
- PIL

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.